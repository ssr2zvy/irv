# irv — managed configuration sync and session logs

This is a source patch for `ssr2zvy/irv`, verified against main at `2832a7f36eb77513a12dad8565d3f56903270f6f`. It implements the later exclusive-editing decision: one editor owns the complete TOML/entrypoint/helper bundle, whether opened in the app or terminal. Logs use a separate one-way, acknowledged delivery protocol.

The existing five-minute idle policy and incremental Tigris workspace storage remain. The ML optimizer and automatic environment/dependency/Fly updater remain deferred. No GitHub workflow is added. No new secret is required. No deployment is performed by the installer.

## 1. Apply the source patch

Extract this ZIP outside your repository checkout. Keep all extracted files together. With Python 3.9+ and Git installed, run:

```sh
python3 /path/to/irv-sync-and-logs-patch/apply_patch.py --repo /path/to/irv --check
python3 /path/to/irv-sync-and-logs-patch/apply_patch.py --repo /path/to/irv
git -C /path/to/irv diff --stat
```

The first command checks affected-file hashes and whether Git can apply the patch; it changes nothing. The second applies it and verifies the resulting file hashes. It does not commit, push, build or deploy. Re-running it detects an already-applied patch.

If an affected file differs from the expected base, the installer stops without changing files. Preserve your work and reconcile those differences against `irv-sync-and-logs.patch`; do not force an overwrite. Unrelated repository changes are allowed. `manifest.json` records the expected before/after hashes and patch checksum.

## 2. Understand the behavior

- Managed files are `config.toml`, its one entrypoint, and explicitly registered `helpers`. Ordinary project files continue to use the workspace snapshot system.
- The app editor and `irv edit` acquire the same sandbox-wide lease. Other editors can read but cannot commit. Leases last 120 seconds and renew every 20 seconds; explicit takeover fences the old editor. Invalid drafts and interrupted edits are recoverable.
- Terminal editing uses `irv edit config.toml` or `irv edit scripts/environment.sh`. `$EDITOR` is supported; the image includes `nano`. Managed canonical files are protected from direct writes. Edit a draft through the CLI, rather than opening the canonical file with a separate editor. The CLI publishes valid disk saves automatically; unsaved editor buffers are not transmitted.
- In the app, draft autosave is separate from **Save changes**, which validates and commits the bundle. Committed changes reach a running agent on its next one-second poll. Offline edits are delivered before setup on the next start. The UI shows pending/applied/error state.
- Removing a helper from management preserves its file. **Delete file** is separate and explicit. Keywords use the same guarded TOML editor and refresh at the next shell prompt.
- Saving configuration does not execute it. **Apply setup & restart processes** explicitly terminates development processes and reruns setup; save ordinary open files first.
- Agent logs retain event ID, session, timestamp, source, stream and sequence. A durable local queue retries until the backend acknowledges exact event IDs; backend deduplication prevents replay duplicates. stdout/stderr are separate. Configured file logs are supported. A raw terminal transcript is not automatically saved.
- `irv logs` reads app history; `--session ID` and `--follow` are supported. `irv logs --local` reads the current local archive. The UI shows current/past sessions, delivery queue depth and the last acknowledgement. Log reads and app editing do not keep compute running.
- Final checkpointing includes log acknowledgement before planned Machine/volume deletion. Provider/container logs are independently polled and failures surfaced, including when the agent cannot start. That provider feed remains best-effort; it has no guaranteed upstream replay.

The complete contract is added to `docs/SYNC_AND_LOGS.md`; configuration examples are in `docs/CONFIGURATION.md`. Local log archives and unacknowledged queues reside on the working volume; loss of that volume before delivery can lose unacknowledged events. Historical app logs use the existing 30-day default retention.

## 3. Checkpoint before upgrading a live installation

Old agents cannot participate in the new editing protocol. Upgrade the backend and both sandbox images as a coordinated maintenance operation.

1. With the existing deployment still running, save work and **Stop** each running environment. Verify its final save and log flush. For a retained stopped environment with an uncertain checkpoint, reopen and stop it using the old deployment first. Keep users out during the upgrade.
2. Back up the application database and verify access to workspace snapshots/working volumes. A stopped Machine retains its old image; changing the image catalog alone does not upgrade it.
3. Build and test the new blank image and the Java image derived from that exact blank image. Build the backend/frontend from the patched source. Do not use the old checked-in JAR or frontend assets.
4. Publish the tested image digests and select them for new Machines. Deploy the new backend; Flyway applies migration V4 automatically. Keep old agents stopped until their Machines have been recreated as described below.
5. In each retained stopped environment's configuration page, choose **Recreate stopped Machine for image upgrade**. The backend checks stopped state, a recorded snapshot, an inactive compute lease, and provider state. It removes the Machine only, retains its working volume, and selects the configured image. Wait for the environment to become cold, then **Start**. The new agent uses that retained volume. Already-cold environments without a retained Machine start normally from the selected new image and their snapshot.
6. Complete the staging checks below before reopening access.

The migration action is also available to the authenticated owner at `POST /api/sandboxes/{id}/rebuild-agent` through the existing authenticated/CSRF-protected API. Use the UI unless automating with an existing session client. Do not run old and new agents concurrently against the same volume. Keep the control plane at the repository's existing one-replica limit; edit-lease serialization does not make all lifecycle/WebSocket routing horizontally scalable.

### Builds and image selection

From the patched repository, with its documented Java/Node/Maven/Python dependencies installed:

```sh
python3 -m pip install -r agent/requirements.txt
bash scripts/build.sh
npm test --prefix frontend
```

`build.sh` rebuilds frontend assets and the JAR and runs Java/Python tests. A Docker source build is also supported by the repository. See `docs/DEPLOYMENT.md` for deployment settings and existing secrets.

Build both sandbox images, substituting your registry/account:

```sh
docker build --platform linux/amd64 -f images/Dockerfile.blank \
  -t ghcr.io/YOUR_ACCOUNT/irv-blank:sync-v1 .
docker build --platform linux/amd64 -f images/Dockerfile.java \
  --build-arg IRV_BASE=ghcr.io/YOUR_ACCOUNT/irv-blank:sync-v1 \
  -t ghcr.io/YOUR_ACCOUNT/irv-java:sync-v1 .
```

Before publishing, run the agent suite in each new image on a host that supports normal Linux UID/GID changes and Unix sockets:

```sh
docker run --rm --entrypoint python3 \
  -v "$PWD/agent:/tests:ro" ghcr.io/YOUR_ACCOUNT/irv-blank:sync-v1 \
  -m unittest discover -s /tests -p 'test_*.py'
docker run --rm --entrypoint python3 \
  -v "$PWD/agent:/tests:ro" ghcr.io/YOUR_ACCOUNT/irv-java:sync-v1 \
  -m unittest discover -s /tests -p 'test_*.py'
```

The two native permission/socket tests must execute successfully, not skip, in this deployment gate. Then push both images and record their immutable `registry/repo@sha256:...` references.

For an installation without image-catalog rows, set `IRV_BLANK_IMAGE` and `IRV_JAVA_IMAGE` to those digests. Existing catalog rows take precedence over these environment variables. To update the catalog, place the digests in `blank-digest.txt` and `java-digest.txt` in your current directory, provide `MAINTENANCE_TOKEN` equal to the deployment's existing `IRV_MAINTENANCE_TOKEN`, and run the repository's manual command:

```sh
python3 scripts/promote.py https://YOUR_BACKEND
```

This command selects digests; it does not run tests or implement the deferred automatic updater. Do not put tokens in the ZIP, source control or digest files.

## 4. Verify in staging

`VALIDATION.md` records exactly what was exercised during patch preparation. Full Maven resolution, image builds, native cross-user/socket enforcement and live Fly/Tigris/PostgreSQL/provider-log delivery were not exercised here.

The existing full-stack fixture can be run after building:

```sh
python3 scripts/local_smoke.py
```

On a restricted development host, the explicitly simulated variant is:

```sh
IRV_SMOKE_SIMULATE_UID=1 python3 scripts/local_smoke.py
```

That variant substitutes UID switching and Unix-socket transport with local execution and loopback HTTP. It validates protocol integration, not the native permission boundary. The simulation fixture is not copied into sandbox images.

Check the following with the actual new images and services:

1. Acquire app editing. A second tab and `irv edit` cannot acquire without explicit takeover. Repeat with the terminal holding the lease. Verify direct write/rename/delete of managed files fails while ordinary project writes work.
2. Save valid and invalid edits, disconnect an editor, allow lease expiry, and take over. Recover its draft. The former editor cannot publish after losing ownership; old committed files remain active for invalid drafts.
3. Edit while cold, start, and verify the committed revision is applied before setup. Add/unmanage/delete a helper. Edit an unmanaged helper, checkpoint and cold-restore it; its later content must survive. Verify a keyword change at the next shell prompt.
4. Run a configured process that writes separately to stdout/stderr and optionally a declared log file. Inspect local logs and current/past app sessions. Disconnect backend delivery, emit logs, reconnect, and check that replay preserves original session/time without duplicate rows.
5. Test final-save failure and missing log acknowledgements. Planned deletion must not discard the working volume. After delivery resumes, verify final save, log flush, Machine/volume deletion, cold restore and historical logs.
6. Test an entrypoint failure and a container that fails before agent connection. Check app platform/provider diagnostics and collector-error visibility. Provider retention/polling gaps remain possible and must not be presented as complete agent-style replay.

## Rollback

Preserve your pre-upgrade database backup, image digests and verified data backups. Reverting source before deployment is an ordinary Git operation. After migration, coordinate rollback of the application database, backend and images using those backups. Do not assume an old agent can write the newly protected managed paths, or that deploying only the old JAR reverses the protocol/schema migration. Verify restored workspace contents before resuming development.

## Package contents

- `irv-sync-and-logs.patch`: source changes, migration, tests and repository documentation.
- `apply_patch.py`: local preflight/application helper.
- `manifest.json`: upstream base identity and before/after checksums.
- `VALIDATION.md`: completed checks and remaining deployment gates.
- This guide.

No JAR, dependency cache, generated frontend bundle, credential, workflow or deployment artifact is included.
