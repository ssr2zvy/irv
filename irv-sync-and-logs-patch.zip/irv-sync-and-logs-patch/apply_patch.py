#!/usr/bin/env python3
"""Apply this patch after exact affected-file preflight. No network, commit or deploy."""
import argparse, hashlib, json, pathlib, subprocess, sys


def digest(path):
    if path.is_symlink():
        raise ValueError(f'Refusing symlink: {path}')
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',default='.',help='irv repository directory')
    parser.add_argument('--check',action='store_true',help='validate without changing files')
    args=parser.parse_args()
    package=pathlib.Path(__file__).resolve().parent
    repo=pathlib.Path(args.repo).resolve()
    result=subprocess.run(['git','-C',str(repo),'rev-parse','--show-toplevel'],capture_output=True,text=True)
    if result.returncode:
        sys.exit('Not a Git working tree. Pass --repo pointing to your irv checkout.')
    repo=pathlib.Path(result.stdout.strip()).resolve()
    manifest=json.loads((package/'manifest.json').read_text())
    patch=package/'irv-sync-and-logs.patch'
    if digest(patch)!=manifest['patch_sha256']:
        sys.exit('Patch checksum mismatch. Extract the ZIP again.')
    observed={}
    for entry in manifest['files']:
        relative=pathlib.PurePosixPath(entry['path'])
        if relative.is_absolute() or '..' in relative.parts:
            sys.exit('Invalid path in manifest.')
        path=repo.joinpath(*relative.parts)
        if not path.resolve().is_relative_to(repo):
            sys.exit(f'Path escapes repository: {relative}')
        observed[entry['path']]=digest(path)
    if all(observed[e['path']]==e['after_sha256'] for e in manifest['files']):
        print('This patch is already applied. Rebuild the backend/UI and sandbox images.');return
    conflicts=[e['path'] for e in manifest['files'] if observed[e['path']]!=e['before_sha256']]
    if conflicts:
        sys.exit('Affected files differ from the expected base; nothing changed:\n'+'\n'.join(conflicts))
    command=['git','-C',str(repo),'apply','--whitespace=error-all']
    subprocess.run([*command,'--check',str(patch)],check=True)
    if args.check:
        print('Preflight passed. No files changed.');return
    subprocess.run([*command,str(patch)],check=True)
    mismatches=[e['path'] for e in manifest['files'] if digest(repo/e['path'])!=e['after_sha256']]
    if mismatches:sys.exit('Post-apply verification failed; inspect your working tree:\n'+'\n'.join(mismatches))
    print('Patch applied and verified. Read README_APPLY.md, rebuild, then perform the staging checks.')


if __name__=='__main__':
    try:main()
    except (OSError,ValueError,subprocess.CalledProcessError) as error:sys.exit(str(error))
