# Validation

Executed locally against main commit 538bca312c674916efafb76a3b2dd8895571e3b3
with this patch, Java 17 and Maven 3.9.11:

- Full Maven test/package: 25 tests, zero failures/errors/skips.
- New arbitrary-controller test: valid bound login accepted; no login, missing
  binding, wrong subject, wrong/revoked certificate, missing ingress secret,
  expired idle/absolute lifetime, missing CSRF and wrong Origin denied.
- The same future route remains 404 through the active auth-only boundary.
- Legacy fallback test and revised legacy HTTP integration tests: controllers,
  old login/mutation routes, cookies and bearer headers do not bypass deny-all.
  The previous legacy password/TOTP success test was replaced because that HTTP
  behavior is intentionally no longer supported; it was not skipped.
- Existing mock OAuth/PKCE/signature/claims/replay and invite tests passed.
- Packaged real HTTP smoke test passed with and without ingress configuration:
  port isolation, unknown-route denial, cookie flags, fail-closed missing config.
- git diff --check passed. ZIP apply.sh applied successfully to a clean worktree
  at the exact base; all resulting changed-file SHA-256 hashes match MANIFEST.json.
- fly.toml, application properties, existing feature/commented code and
  deployment configuration have no changes.

Reproduce from repository root (use throwaway test values, not production secrets):

```sh
IRV_ENCRYPTION_KEY=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA= \
IRV_BLOB_DIR=/tmp/irv-patch-test-blobs mvn -f backend/pom.xml test package
python3 scripts/test-auth-only.py --jar "$PWD/backend/target/irv-0.1.0.jar"
```

No live Safari/Cloudflare/ZITADEL test or deployment was performed. Existing
Flow 2 live enrollment, forwarding and recovery-policy checks remain required.
