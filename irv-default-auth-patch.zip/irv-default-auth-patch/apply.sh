#!/bin/sh
set -eu
patch_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
git rev-parse --show-toplevel >/dev/null
if [ "$(pwd -P)" != "$(git rev-parse --show-toplevel)" ]; then
  echo 'Run this script from the irv repository root.' >&2
  exit 1
fi
git apply --check "$patch_dir/irv-default-auth.patch"
git apply "$patch_dir/irv-default-auth.patch"
echo 'Applied. Review git diff. Nothing was committed, pushed or deployed.'
