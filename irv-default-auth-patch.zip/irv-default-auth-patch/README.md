# irv default-authentication and manual-operations patch

Base: ssr2zvy/irv main, commit 538bca312c674916efafb76a3b2dd8895571e3b3.
Flow 2 is already applied in this base. Do not reapply the earlier Flow 2 ZIP.

## Apply

Save current work, extract this ZIP, then from the irv repository root run:

```sh
sh /absolute/path/to/irv-default-auth-patch/apply.sh
```

If the check fails, stop and reconcile changes; do not force application. Review
the resulting diff and use your normal commit/deployment process. No branch,
commit, push, provider settings, account, invite or deployment was changed by
preparing this ZIP. No new secrets are required for this patch.

## Changes

- Every non-bootstrap request reaching the ZITADEL security chain requires the
  same valid account/session/certificate binding by default, without a protected
  route list. Includes subject/issuer consistency, expiry and Origin checks; CSRF
  remains enabled.
- The existing terminal auth-only allowlist still denies unknown routes, including
  for authenticated users. Nothing enables sandbox, terminal, logs or previews.
- The inactive non-auth-only legacy fallback now denies all requests, replacing
  its blanket permit-all behavior. Switching profiles will NOT enable a usable
  legacy application; future runtime integration is still required.
- Manual documentation covers listing accounts, role removal plus restart to
  revoke access, operator-only recovery, issuing/withdrawing invites and reviewing
  interrupted redemptions. No admin UI or self-service recovery is introduced.

Read docs/manual-auth-operations.md and docs/default-authentication.md after
applying. Copies are included here for review.

The patch does not change fly.toml, application properties, active profiles,
container/workflow configuration or commented-out feature code. Future resource
ownership checks and ongoing WebSocket expiry enforcement still belong to those
features when implemented.
