# IRV invite and sign-in patch

Base: ssr2zvy/irv main `4f64af9f1c97af4754ae062269e5fc0453aed87b` (PR #39). Includes only the changes after the previous authentication UI patch.

## Apply

From a clean checkout of this base, run:

```sh
git apply --check /path/to/irv-invite-signin-patch/changes.patch
git apply /path/to/irv-invite-signin-patch/changes.patch
```

Alternatively run `bash /path/to/irv-invite-signin-patch/apply.sh` from the repository root. If the check fails on a newer revision, reconcile changes instead of overwriting files. Review, commit, and deploy through the existing workflow. This ZIP does not deploy or set secrets.

## Changes

- One Sign in action opens the existing ZITADEL hosted login; no redundant Sign in heading on the initial page. Provider account selection can still precede the passkey prompt.
- New `IRV_AUTH_INVITE_CODES_JSON` array accepts original random invite strings and UTC expiry dates. The backend hashes them; the existing hash-only setting still works.
- Same durable reservation ledger enforces single use across restarts and format migration. Expiry conflicts fail startup, rather than silently changing policy.
- Value-free validation errors, combined 1000-invite limit, and no new credential logging.
- Auth admission, CSRF, callback/session validation, and default-denied unfinished endpoints are unchanged.

## Configure after deployment

Follow **SETUP.md** in this ZIP (also installed as `docs/signup-setup.md`). It gives the ZITADEL service account/PAT steps, the exact Fly secret names and JSON format, and first-signup instructions. No repository invite script is required.

## Verification

Backend JUnit suite and nine frontend behavior tests are run for this patch. Tests cover plaintext parsing, expiry, malformed-input redaction, mixed formats, duplicate expiry conflicts, combined limit, successful mocked enrollment and replay rejection after reopening the ledger. Patch application is checked against the stated base. Live ZITADEL/Fly/Safari signup and visual browser testing are not performed.
