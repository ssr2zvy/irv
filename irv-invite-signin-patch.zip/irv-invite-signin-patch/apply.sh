#!/usr/bin/env bash
set -euo pipefail
patch_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
git rev-parse --show-toplevel >/dev/null
if [[ -n "$(git status --porcelain)" ]]; then
  echo 'Use a clean working tree before applying this patch.' >&2
  exit 1
fi
git apply --check "$patch_dir/changes.patch"
git apply "$patch_dir/changes.patch"
echo 'Patch applied. Review changes, deploy, then follow SETUP.md.'
