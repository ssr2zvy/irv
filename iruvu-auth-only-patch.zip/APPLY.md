# Apply the auth-only preparation patch

Base: `ssr2zvy/irv` main, commit `319fe96dd6f390d702fd08adefb536d16e5c7dff` (single-app tunnel patch applied).
No deployment or repository push was performed while creating this ZIP.

1. Extract this ZIP outside the repository, or into an untracked temporary folder.
2. In a clean checkout of current main, create a feature branch:

```sh
git switch main
git pull --ff-only
git switch -c auth-only-diagnostics
```

3. Apply using the actual extracted patch path:

```sh
git apply --check /path/to/auth-only.patch
git apply /path/to/auth-only.patch
git diff --check
git diff --stat
```

If the check fails, stop and reconcile against your new main; do not force or partially apply.
If your branch already has unrelated work, commit/stash it before switching branches.

4. Review `docs/auth-only-testing.md`, then commit and merge through your normal process.
5. Deploy with the existing workflow/deploy.sh. No extra workflow, app or deployment token.
6. Open https://iruvu.space using the installed client identity. The old success page is now
   an authentication diagnostic page. The existing mTLS block rule stays enabled.

## Immediately after deploying

- Spring connectivity reports Passed.
- Certificate evidence reports Not configured until the optional protected header forwarding
  is set up. Spring approval also needs the configured fingerprint allowlist.
- Auth0, password/passkey evidence, user admission, user-certificate mapping and sessions
  explicitly report Not implemented. No login button pretending to work is included.
- The overall result remains Authentication incomplete.
- Internal /api/health still serves operational readiness on 8080; it is absent on 8081.

Only TUNNEL_TOKEN remains required to run the existing connector. No Auth0, database, Tigris
or sandbox-provisioning secrets are required to boot this patch. Optional certificate checking
requires two operator values described in SETUP.md and the repository documentation.

## Rollback

Revert the patch commit and redeploy. This restores the previous temporary-page behavior.
Keep Cloudflare's existing certificate enforcement enabled. No data migration is performed.
Switching profiles alone does not implement a completed production authentication system.
