# Validation performed

- All production Java sources compiled with Java 17 against dependencies extracted from the
  existing app JAR. No new Maven dependencies added.
- Standalone Spring context check: all 20 legacy component types plus DataSource absent;
  the auth-only configuration present. No legacy database boot or account bootstrap.
- Real HTTP smoke script passed both unconfigured and configured cases: UI/assets/status,
  strict port/route/method allowlists, fake cookies/JWTs never authenticate, no secret/fingerprint
  disclosure, forged/missing/wrong/duplicate/revoked/malformed evidence rejected, approved and
  unapproved fingerprints distinguished, health 200 -> 503 -> 200, no Java legacy data creation.
- JavaScript syntax check passed. TOML parsed, no public Fly services added.
- Patch clean-applied to an archive of the documented base commit. git diff --check passed.

## Limits

A full Maven build was attempted but Maven Central DNS failed in this environment. Compilation
and runtime checks used locally available dependencies, not a freshly resolved build. No Docker
image build, real Fly deployment, Cloudflare header-rule application, iPhone UI test, Auth0 login,
password+passkey sequence or session-binding test was performed. They are not claimed complete.

The UI is a functioning diagnostic shell and polling client, not a completed authentication flow.
The certificate implementation relies on the documented trusted forwarding configuration and
allowlist; the local HTTP tests exercise that contract, not Cloudflare's actual edge.
