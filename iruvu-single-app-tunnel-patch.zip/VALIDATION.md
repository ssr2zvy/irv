# Executed checks

- Patch applied to a clean base export, including deletion of obsolete connector files.
- Java 17 compiled the changed classes against the existing repository JAR dependencies.
- Existing app plus new classes: /api/health changed 503 -> 200 -> 503 as a simulated local connector became ready and then unavailable. Public status listener served the message and blocked API paths.
- Deployment readiness script succeeded when both components were ready.
- Initialization check: token removed from supervisor exec environment, restricted file/directory modes, missing-token rejection. Group lookup was mocked; actual cross-user permission enforcement was not exercised.
- Real installed Supervisor with fake services: connector crash restarted without restarting Java; exhausted startup retries triggered group shutdown; TERM stopped the group. Test substituted the local root user for container users because this environment cannot exercise their setgroups transition.
- Stub Fly CLI: deploy success requires readiness success, build failure skips readiness, readiness failure propagates, and stop targets the same app Machine.
- Shell/Python syntax, TOML parsing, matching Dockerfiles, unchanged workflow.

# Remaining deployment verification

Fresh full Maven/image build, actual final-image user transitions, real Fly SSH readiness command, and Cloudflare tunnel/domain connection were not executed. No repository push, deployment, secret modification, or live resource deletion was performed.
