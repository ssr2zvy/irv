# One app/Machine replacement patch

Base: irv main 7ed96ea270060409018adb3eba109736b50218d2, PR #30 already applied.

Extract outside your checkout. In a clean repository:

```bash
git switch -c single-app-tunnel
git apply --check /absolute/path/to/single-app-tunnel.patch
git apply /absolute/path/to/single-app-tunnel.patch
git diff
git status
```

If the check fails, reconcile the newer repository; do not force it. Commit the changed files, merge, and follow SETUP.md (also installed as ci-cd/deployingtofly.md).

Before deploying:
- Keep/restore TUNNEL_TOKEN in Fly app **iruvu**. No second app or deployment token needed.
- Stop any separate iruvu-tunnel Machine created from the previous instructions. Skip if none exists.
- Set the iruvu.space Cloudflare route to **http://127.0.0.1:8081**.
- Run the existing workflow with action **deploy**. It now starts both processes and verifies readiness. Its stop action stops the single Machine containing both.

Removes the separate connector deployment files and updates the application Dockerfiles, startup supervision, health endpoint, and deploy.sh. The workflow file is unchanged. No public Fly IPs required. No live resources are automatically created/deleted and no secrets or Cloudflare routes are automatically changed by git apply.

The two processes have different OS users but share a kernel. This step does not implement the future mTLS/Auth0/session protections. Hosting remains the existing one-Machine allocation; monitor added connector resource usage.
