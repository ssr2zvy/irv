# irv: ZITADEL login + certificate-bound session patch

Based on `ssr2zvy/irv` main commit `fe642219a92591380a8cb52fa358cb336f5f99bb`.

## Apply

Extract outside your repository checkout. From the extracted folder:

```sh
sh apply.sh /path/to/irv
```

Or, from the repository root:

```sh
git apply --check /path/to/irv-zitadel-login-patch/irv-zitadel-login.patch
git apply /path/to/irv-zitadel-login-patch/irv-zitadel-login.patch
```

The script does not commit, push, deploy, replace a branch, or force conflicts. Existing tracked edits must be committed or otherwise preserved before applying. If the check fails on newer source, stop and reconcile the actual changes; do not force it or replace the repository wholesale.

## What changes

- Real Spring OAuth2/OIDC login through your existing ZITADEL app, Authorization Code + S256 PKCE, fresh-login request, signature/issuer/audience/expiry/nonce/state verification.
- Strict verified-passkey evidence, required project role, explicit user admission, and account-certificate matching.
- Opaque Secure/HttpOnly/SameSite session cookie bound to the exact certificate; idle/absolute expiry, CSRF/Origin checks, logout and restart revocation.
- Updated diagnostic page, current documentation, security-flow tests and actual HTTP cookie/isolation checks.
- Auth0/password-AND-passkey preparation references replaced in the diagnostic runtime and its active setup instructions.
- Legacy sandbox runtime remains disabled in `auth-only`; it is not silently considered migrated to this new session scheme.

## What you must configure before login can succeed

Read `SETUP.md` here, or `docs/zitadel-login.md` in the patched repo.

1. Cloudflare must overwrite the trusted certificate headers, including the ingress secret. Existing mTLS alone does not automatically provide those headers to Spring.
2. Fly needs `IRV_AUTH_INGRESS_SECRET` and `IRV_AUTH_ADMISSIONS_JSON` mapping the test user's immutable ZITADEL ID to its certificate fingerprint.
3. That test user needs an enrolled passkey and `irv_user` role. No user, passkey, invitation or grant is created by applying this patch.

The existing `TUNNEL_TOKEN` remains required. Issuer/client/project/organization identifiers are already included; no ZITADEL admin PAT or client secret is required at runtime. Missing setup produces denied login or truthful diagnostic status, not a bypass.

After configuration, use the existing `ci-cd/deploy.sh deploy` or existing GitHub deploy workflow. This ZIP does not add or modify either deployment mechanism.

## Boundaries

Implemented and tested locally: the backend login/session mechanisms above. Not yet verified: live ZITADEL/Safari passkey flow, actual Cloudflare header forwarding/rules and deployment. Automated single-use invitations/enrollment remain separate. Sandbox APIs, terminals, logs, previews and their authorization remain disabled in this profile. Sessions live in memory on the current single Machine; restart/deploy signs everyone out.

No payment/trial/billing operation or paid feature is introduced. Existing provider limits and Fly/domain costs still apply.
