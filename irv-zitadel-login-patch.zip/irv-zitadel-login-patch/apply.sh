#!/bin/sh
set -eu
patch_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ "$#" -ne 1 ]; then
  echo 'Usage: sh apply.sh /path/to/irv' >&2
  exit 2
fi
repo=$(git -C "$1" rev-parse --show-toplevel)
if ! git -C "$repo" diff --quiet || ! git -C "$repo" diff --cached --quiet; then
  echo 'Stop: preserve/commit existing tracked changes before applying this patch.' >&2
  exit 1
fi
if git -C "$repo" apply --reverse --check "$patch_dir/irv-zitadel-login.patch" 2>/dev/null; then
  echo 'This patch is already applied.'
  exit 0
fi
git -C "$repo" apply --check "$patch_dir/irv-zitadel-login.patch"
git -C "$repo" apply "$patch_dir/irv-zitadel-login.patch"
echo 'Patch applied. Read docs/zitadel-login.md before configuring and deploying.'
