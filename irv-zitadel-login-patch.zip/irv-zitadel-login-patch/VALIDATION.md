# Validation performed

- All 16 Maven tests passed with a randomly generated, throwaway legacy encryption key. No production credential used.
- Nine new test methods use an actual local mock OIDC token/JWKS server and RSA-signed ID tokens through Spring's real OAuth login filters. They exercise multiple positive/negative cases:
  - S256 PKCE, no client secret, nonce/state, fresh-login parameters, token exchange and session-ID rotation.
  - Valid session accepted; password, unverified U2F, stale authentication, missing role, unadmitted subject, wrong issuer/audience, expired token, wrong nonce and bad signature rejected.
  - Wrong state, callback replay and different callback certificate rejected.
  - Stolen cookie with another approved certificate rejected; missing/duplicate/spoofed/revoked certificate evidence rejected; bearer token alone grants no session.
  - Polling leaves idle timestamp unchanged; idle and absolute expiry enforced.
  - CSRF and exact Origin protect mutations; logout invalidates the session.
  - Sandbox routes and the other listener remain isolated.
- Packaged JAR started twice, with and without auth configuration. Real HTTP smoke checks passed for actual Secure/HttpOnly/SameSite=Lax, host-only cookie attributes, internal health versus external listener routing, denied legacy routes, and missing-configuration denial.
- Public discovery metadata was read from the user's existing ZITADEL instance; no administrative, trial, billing, user or grant mutation was performed.
- Git patch whitespace and clean-base application checked.

Not performed: live passkey enrollment/login, Cloudflare configuration, Fly deployment, or a claim of full production-security certification. The exact remaining setup and acceptance checks are in SETUP.md.
