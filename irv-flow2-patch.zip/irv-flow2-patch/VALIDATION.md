# Validation

- Full Maven package/test run: 23 tests, zero failures/errors/skips across six suites. Lifecycle test also executes 20 internal checks.
- Real packaged-JAR HTTP smoke: passed with missing configuration and configured trusted ingress. Verified health/listener isolation, forbidden legacy endpoints, fail-closed ingress, and actual Secure/HttpOnly/SameSite=Lax/Path=/ host-only session cookies.
- OAuth tests use real signed mock-provider JWTs and code/PKCE exchange. Covered bad signature/issuer/audience/nonce/expiry/AMR/role, wrong state, replay, certificate switching, session limits, CSRF and logout.
- New tests cover distinct account sessions using the same certificate, signup endpoint provisioning, no authenticated session from enrollment alone, protected resume/Origin, provider request payloads, one-winner concurrent invite claims, durable rejection after ledger reopen, rejected/expired invites, ambiguous provider failure, and invite enforcement with the certificate gate disabled.
- JavaScript syntax check, Python syntax check and git diff --check passed.
- Clean base patch application passed; all 23 changed-file hashes match the manifest.
- Offline invite generator checked for 43-character token output, matching SHA256 JSON and owner-only file permissions.

Not performed: live ZITADEL writes, live Fly deployment, real iPhone passkey enrollment, provider plan/account inspection, or browser visual inspection. The hosted enrollment route and API payloads were checked against provider docs/source, but still need the deployed acceptance test. Existing provider policies and trusted Cloudflare header forwarding remain requirements.

Provider failures are not silently retried. Incomplete signup can leave an unfinished provider user and a reserved invite requiring operator review. See SETUP.md.
