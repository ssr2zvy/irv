#!/bin/sh
set -eu
patch_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
git rev-parse --show-toplevel >/dev/null
if ! git diff --quiet || ! git diff --cached --quiet; then
  echo 'Commit or safely stash tracked changes before applying this patch.' >&2
  exit 1
fi
git apply --check "$patch_dir/irv-flow2.patch"
git apply "$patch_dir/irv-flow2.patch"
git diff --check
echo 'Applied locally. Read docs/flow2-enrollment.md before deploying. Nothing committed, pushed or deployed.'
