# irv Flow 2 patch

Based on ssr2zvy/irv main commit 83ca1faeaac3a38017cffca7377067211c65ba7d (the previous ZITADEL login patch is already present).

## Apply

1. Extract this ZIP into a folder.
2. Open your irv repository on main or your chosen working branch; save any existing changes first.
3. From the repository root run `sh /absolute/path/to/irv-flow2-patch/apply.sh`.
4. Review the diff, then commit/push through your usual process. The script never changes branches, commits, pushes or deploys.
5. Follow SETUP.md, also installed as docs/flow2-enrollment.md. Keep certificate admission enabled now.

If git apply --check fails, stop and reconcile with your actual repository version. Do not force the patch, overwrite unrelated work, or apply the earlier login patch again.

## Included

- Removes the permanent certificate/account registry. Keeps exact-certificate binding within each login transaction and session.
- Invite-gated new-user creation, username plus separate email/profile fields, provider-hosted passkey enrollment and existing OIDC passkey sign-in.
- Single-use expiring invites, with a persistent reservation ledger on the existing volume; offline invite generator.
- Real signup UI and diagnostics. Enrollment opens on ZITADEL; return to irv and click Sign in after enrolling.
- Certificate policy can later be disabled independently; invites remain required.

## Configuration still required

A scoped enrollment service-account PAT, IRV_AUTH_INVITES_JSON, and IRV_AUTH_ENROLLMENT_ENABLED=true. Existing ingress secret/tunnel/Cloudflare rules remain. Remove obsolete permanent-map secrets. Read SETUP.md for exact values and least-privilege role setup.

No live ZITADEL account, membership, role, Cloudflare rule, Fly secret or deployment was changed while preparing this ZIP. No payment implementation or billing API is included. Local tests are not a substitute for the final iPhone enrollment/login test.

The invite ledger contains invite hashes and provisioning status/user IDs only, not certificate/account mappings. It is persistent so used invitations cannot become usable again on deployment. Sessions and passkey-setup links remain in memory.

Partial provider failure consumes/reserves the invite and requires operator review; the patch deliberately does not promise cross-provider transactional rollback or automatic recovery.
