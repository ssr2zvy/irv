# irv: fixed five-minute lifecycle patch

This is a source patch for `ssr2zvy/irv`, prepared against main commit:

`ae74fbbf4a267b0fc7fe21fccf3adfdd7ca499a7`

It implements the fixed policy and places the adaptive optimizer design in an entirely commented `backend/src/main/java/dev/irv/DeferredCostOptimizer.java`. It does not add GitHub workflows or implement the separately deferred environment update worker.

## Behavior after rebuilding and upgrading

- New sandbox Machines always attach a working volume.
- After the last active terminal/preview lease expires, wait **five minutes**. The last heartbeat can remain valid for up to 45 seconds after a socket closes.
- Begin a final incremental save and log flush; only after verification commit resource cleanup, delete the Machine, then delete the working volume. Retain workspace chunks in Tigris and their manifests in the app database.
- Returning before cleanup commits cancels it and unfreezes work. Returning after the irreversible commit finishes cleanup and recreates from the saved state.
- Failed save/log acknowledgement retains the working copy. Partial provider deletion is retried using persisted state; it does not blindly delete a volume based on an older periodic snapshot.
- A **recovery safety exception** retains an environment if the conservative cold-start estimate exceeds 180 seconds. Its initial size formula blocks cold deletion above approximately 400 MiB; slow/failed measured cold starts can also block it. This is deliberate preservation of the earlier startup limit, not adaptive cost optimization. See `docs/ALGORITHM.md` for exact behavior and limitations.
- Manual Stop still saves and stops while retaining the volume. Legacy stopped/suspended/volume records require reopening before automatic cleanup. Existing ephemeral Machines are not migrated live; their next cold creation uses a volume.
- Costs remain estimates. Telemetry and fixed-policy history are recorded; no predictive model is trained.

## Extract and apply

1. Extract this ZIP to any directory. It contains an `irv-fixed-policy-patch` folder. Keep its files together.
2. Open a shell **in your irv repository**. Check `git status --short` and preserve any work before applying. You can use your current branch or create a branch such as `git switch -c irv-fixed-idle-policy`.
3. Point the commands below to the extracted folder. Do not paste the literal placeholder path.

```sh
python3 /absolute/path/irv-fixed-policy-patch/apply_patch.py --repo . --check
python3 /absolute/path/irv-fixed-policy-patch/apply_patch.py --repo .
git diff --check
git diff --stat
```

On Windows, use `python` if that is your Python 3 command. Git must be installed. The helper validates the contents of every affected source file before applying. It does not require a particular branch name, commit, push, deploy, or print secrets. Unrelated branch changes are allowed if all affected files still match. It also recognizes an already-applied patch.

If validation reports conflicting/changed files, stop and review them; do not force-copy replacements or reset your branch. No files are modified when the preflight check fails. The ZIP also includes the ordinary `irv-fixed-policy.patch` for manual review/application with `git apply --check` and `git apply`.

## Build the patched code

Requirements remain Java 17+, Maven 3.9+, Node 22 and Python 3.12+.

```sh
python3 -m pip install -r agent/requirements.txt
bash scripts/build.sh
npm test --prefix frontend
python3 scripts/local_smoke.py
```

`build.sh` now uses **`mvn clean verify`**, so the removed optimizer classes cannot linger in an old build directory. It rebuilds the UI and updates both `backend/target/irv-0.1.0.jar` and `dist/irv.jar`.

**Do not run the old checked-in JAR or old generated frontend assets and expect this patch to be active.** Binary/generated build outputs are intentionally not bundled in this source patch. Docker deployment builds the patched sources afresh.

The additional lifecycle checks are in `FixedPolicyChecks.java`; `LifecycleTest` invokes them through JUnit. `docs/VALIDATION.md` records exactly what was executed locally and what still requires your environment.

## Upgrade the running deployment

1. Back up the app database and preserve the existing object store and encryption key. The new V3 migration adds cleanup/retry metadata and clears old scheduled optimizer decisions. Existing snapshots, accounts and logs are retained.
2. Build and publish both sandbox images with the patched agent, following `docs/DEPLOYMENT.md`. The Java image must inherit the rebuilt blank image. Do not reuse an older image digest.
3. Rebuild and deploy the patched backend/UI. Keep **one backend replica**; the application still uses in-process lifecycle locks and WebSocket ownership.
4. Configure/promote the new blank/Java image references using the existing documented mechanism. The `image:blank`/`image:java` catalog, if present, takes precedence over previously stored sandbox image references at cold creation.
5. Existing running Machines retain their old agent until their image is updated or they are recreated. Before changing an existing Machine image, stop application writes and obtain a successful checkpoint; protect the volume and the selected Tigris snapshot. Existing ephemeral working disks especially require that checkpoint before image replacement. Do not manually delete their only working copy.
6. An old agent cannot provide the new `logs_flushed` acknowledgement: this patch **retains resources and reports an error** rather than assuming logs were saved. Upgrade such a Machine's image while preserving its working volume, or perform a separately verified checkpoint/recreation procedure. Do not bypass the acknowledgement guard to force cleanup.
7. In staging, create a small sandbox, write a marker file, leave its terminal/previews, observe the five-minute countdown and verified cleanup, then reopen and check the file and session logs. Also exercise a failed save and a return during saving. Real Fly/Tigris deletion, process freezing, restore speed and billing require this credentialed check; the bundled local simulation does not prove provider behavior.

`IRV_WORKING_STORAGE` and `IRV_SUSPEND_ENABLED` no longer select runtime policies. New Machines always use a volume and the fixed policy never automatically suspends. Existing `.env` files do not need a new secret. Keep your configured volume size, provider credentials, object store and image references.

## Contents and verification

- `irv-fixed-policy.patch`: all code, tests, migration, UI and documentation changes.
- `apply_patch.py`: preflight, safe application and result verification.
- `manifest.json`: upstream base commit plus before/after SHA-256 hashes for every changed file.
- `VALIDATION.md`: the patch's validation record, also installed as `docs/VALIDATION.md`.

Local verification passed 20 Java lifecycle scenarios, 8 Python tests, 2 UI helper tests, a UI production build and a real backend/agent save-delete-restore simulation. A fresh Maven dependency resolution was blocked by this environment's unavailable proxy; Java compilation and local execution used the dependencies bundled in the repository's JAR. No live cloud deployment is claimed.

To undo an unapplied deployment's source changes, inspect `git diff` and use your normal Git workflow. The patch does not automatically reverse the database migration or restore deleted provider resources. Any valid cold sandbox reopens from its verified snapshot.
