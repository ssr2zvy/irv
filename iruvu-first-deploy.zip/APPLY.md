# Apply the first private deployment patch

Built against ssr2zvy/irv main commit 5476d48e01493acccad1ae3dd8ee54287acd4727.

1. Extract this ZIP outside your repository.
2. In a clean irv checkout, create a branch: `git switch -c iruvu-first-deploy`.
3. Run `git apply --check /absolute/path/to/iruvu-first-deploy.patch`.
4. If that succeeds, run `git apply /absolute/path/to/iruvu-first-deploy.patch`.
5. Review `git diff`, then read `ci-cd/deployingtofly.md` for settings, token setup, private access, and limitations. Commit and merge through your normal review process.

If the check fails, do not force it: the repository changed and needs reconciliation.

Defaults: existing app iruvu; iad region; 1 shared CPU; 1 GB RAM; 1 GB persistent app volume. Deployment creates the first Machine and volume. No public service. PostgreSQL and Tigris are not required. Existing authentication remains, pending the separately agreed replacement.

Validation: shell syntax, TOML parsing, identical container files, and deploy/stop routing using a stub Fly CLI passed. The existing checked-in JAR booted with the new external profile, returned HTTP 200 health, and created an H2 database. This does not validate a freshly built JAR. Maven rebuild was blocked by Maven Central DNS access. Docker was unavailable; the root-to-unprivileged entrypoint transition could not be exercised because this environment forbids changing process groups. No Fly deployment was performed. GitHub denied connector write access, so no PR was created.
