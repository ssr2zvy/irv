# Apply the separate tunnel connector patch

Based on ssr2zvy/irv main a5a21743a68d4bf2509703cc5ac809fb06851ee7 (PR #29).

Extract this ZIP outside the checkout. In a clean irv checkout:

```bash
git switch -c separate-cloudflare-tunnel
git apply --check /absolute/path/to/separate-tunnel.patch
git apply /absolute/path/to/separate-tunnel.patch
git diff
git status
```

If the check fails, stop and reconcile the newer repository; do not force application.

Read `ci-cd/tunnel/README.md` after applying, or the identical SETUP.md included here. Commit the specific changed files, merge through your normal review, then follow its numbered deployment steps.

This patch does not create Fly apps, move secrets, allocate IPs, or deploy automatically. The existing Java deployment script/workflow is unchanged. There is no new workflow. The connector has its own Dockerfile and Fly config, deployed independently using the documented Fly command.

The proposed new app is iruvu-tunnel, in the same Fly organization/private network as iruvu. It runs one 256 MB shared-CPU Machine without a volume. This adds hosting cost. TUNNEL_TOKEN must be set only on that new app and removed from iruvu. No token value is included in this ZIP.

Validation: patch applied successfully to a clean export of the base commit; TOML parsed with no public services on either app; existing Java Dockerfiles, entrypoint, deploy.sh and workflow unchanged. New Java binding compiled with Java 17 against the repository JAR dependencies; a local runtime check verified IPv6 status access, private health, and rejection of API/error paths at the status port. No full fresh Maven/container build or live Fly/Cloudflare deployment was performed. Connector readiness and cross-Machine routing require the post-deployment checks in SETUP.md.
