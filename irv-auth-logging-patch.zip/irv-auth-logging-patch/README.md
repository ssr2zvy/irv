# irv authentication logging patch

Base: ssr2zvy/irv main b4e352626541f9a9220b466fe31e68b21f3b0c7f.
Requires the already-merged Flow 2 and default-authentication patches.

## Apply

Save existing work. Extract this ZIP. From your irv repository root:

```sh
sh /absolute/path/to/irv-auth-logging-patch/apply.sh
```

The script checks before applying. If it fails, stop and reconcile the repository
version; do not force it. Review the diff, then commit and deploy through your
usual process. Nothing is committed, pushed or deployed by the script.

## Included

- Shared outer request logger, covering early rejections and future endpoints.
- Structured authentication stage events: trusted ingress/certificate, OAuth
  transaction and token processing, passkey/freshness/role, invite signup and
  provider provisioning, session validation/expiry/activity/logout.
- Request IDs, separate login/signup flow IDs and non-credential session references.
- Closed event schema and secret-exclusion tests. No bodies, raw unknown paths,
  query strings, tokens, cookies, invite values or enrollment links in audit logs.
- JSON-only stdout audit lines for existing Fly capture; normal console output
  remains available. No new service, secrets, database or admin endpoint.
- Documentation and regression tests; see VALIDATION.md for executed checks.

Read docs/authentication-logging.md (also included here). The active auth-only
profile, deployment settings, and disabled features are preserved. No commented
feature code is uncommented. Logging does not implement future sandbox/terminal
permissions or enable self-service recovery.

## Limits

Cloudflare-blocked traffic does not reach Java and is outside this patch.
ZITADEL internal events and browser console messages are not collected. Library
validation failures are grouped where precise attribution is unavailable. Stage
success is recorded only after the relevant validation returns successfully.

The new logs are operational stdout, not a durable/tamper-proof audit archive.
Every received servlet request is logged, including health/status polling. Sink
failure or process termination can lose logs. Do not enable security DEBUG/TRACE
or add raw exception messages to compensate.
