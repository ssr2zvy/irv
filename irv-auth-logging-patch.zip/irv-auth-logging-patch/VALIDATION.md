# Validation

Base: b4e352626541f9a9220b466fe31e68b21f3b0c7f. Java 17, Maven 3.9.11.

- Full Maven test + package: 32 tests, zero failures/errors/skips.
- Real mock-provider OAuth login: PKCE, session rotation and existing security
  regressions pass with the instrumented token client and decoder.
- New logging assertions cover transaction correlation, ID-token/OIDC validation,
  passkey/freshness/role rejection, wrong ingress/revoked certificate, unsupported
  method/route, Origin/CSRF rejection, expiry, activity and logout.
- Signup tests cover successful stages and failure at each of user creation,
  enrollment-link creation and role grant; failures remain reserved for review.
- Captured JSON is checked for a closed field schema and absence of supplied
  credentials, personal form fields, callback data, raw unknown URLs and provider
  exception text. Logging references differ from servlet session IDs.
- Async completion, context cleanup on exceptions and logging sink failure tested.
- Packaged real HTTP smoke checks pass with ingress configuration present/absent:
  stdout contains standalone JSON, requests pair with exactly one completion,
  secrets do not appear, and route/port isolation plus cookie flags are preserved.
- git diff --check passes. apply.sh succeeds against a clean base checkout; all
  20 changed-file hashes match MANIFEST.json.
- No fly.toml, application-auth-only.properties, CI/deploy or commented feature
  changes. No live provider, Cloudflare, Fly secret or deployment mutation.

Reproduce from the repository root with disposable test storage/keys:

```sh
IRV_ENCRYPTION_KEY=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA= \
IRV_BLOB_DIR=/tmp/irv-audit-test-blobs mvn -f backend/pom.xml test package
python3 scripts/test-auth-only.py --jar "$PWD/backend/target/irv-0.1.0.jar"
```

These are local automated tests, not a live iPhone/ZITADEL/Cloudflare enrollment
run. Operational log retention and hosted provider/edge events are outside scope.
