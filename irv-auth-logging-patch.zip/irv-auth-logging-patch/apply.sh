#!/bin/sh
set -eu
patch_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
root=$(git rev-parse --show-toplevel)
if [ "$(pwd -P)" != "$root" ]; then
  echo 'Run from the irv repository root.' >&2
  exit 1
fi
git apply --check "$patch_dir/irv-auth-logging.patch"
git apply "$patch_dir/irv-auth-logging.patch"
echo 'Applied. Review git diff. Nothing was committed, pushed or deployed.'
