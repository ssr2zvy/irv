#!/usr/bin/env bash
set -euo pipefail
patch_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
git rev-parse --show-toplevel >/dev/null
if [[ -n "$(git status --porcelain)" ]]; then
  echo 'Use a clean working tree before applying.' >&2
  exit 1
fi
if git apply --check "$patch_dir/changes.patch" 2>/dev/null; then
  git apply "$patch_dir/changes.patch"
elif git apply --check "$patch_dir/upgrade-from-24-hour.patch" 2>/dev/null; then
  git apply "$patch_dir/upgrade-from-24-hour.patch"
else
  echo 'Neither patch matches this checkout. Reconcile its changes before applying.' >&2
  exit 1
fi
echo 'Applied. Review, deploy, then follow SETUP.md.'
