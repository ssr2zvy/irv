# IRV two-hour, single-use invite patch

Base: ssr2zvy/irv main `445c99e3549576a88b798b0a80c1e96914cadb44` (PR #40).

This replaces the previous irv-single-invite-patch.zip. It includes the single-string secret and changes automatic expiry to two hours from first enabled startup. A durable claim immediately invalidates the code for all subsequent signup attempts, including after partial failure. Redeployments never renew the timer or reset consumption.

## Apply

From the repository root, with a clean working tree:

```sh
bash /path/to/irv-two-hour-invite-patch/apply.sh
```

The helper checks applicability before modifying files. It selects changes.patch for the recorded main, or upgrade-from-24-hour.patch if the previous single-code patch has already been applied and committed. If neither applies, it stops for reconciliation. Do not apply both manually. No code is deployed by the helper.

Review, commit and deploy through the existing workflow. Then follow SETUP.md. Set your own 43–128-character letters/digits/hyphens/underscores string in IRV_AUTH_INVITE_CODE. Keep the enrollment PAT and enable setting. Remove nonempty JSON invite settings when switching to this mode.

## Existing 24-hour codes

The database migration shortens old deadlines by 22 hours exactly once, preserving original activation time. Already older than two hours means immediately expired. Used codes remain blocked. A different string receives its own two-hour window. Preserve the existing /data volume.

## Verification

72 backend tests and 9 frontend behavior tests passed. Checks include two-hour expiry, concurrent/durable one-time use, exact-string validation, rotation, migration, provider failure, and unchanged authentication controls. Main and 24-hour upgrade patch application checked and resulting bytes compared. Live Fly/ZITADEL/Safari signup remains to be checked after deployment.
