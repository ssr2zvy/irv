# Apply the irv workflow cleanup

This is a small patch ZIP, not a replacement application archive.

Prepared against `ssr2zvy/irv` main at
`a6b94d7658808e7bfdba2af5ef869275811206d2` on 2026-10-14.
The project is at the repository root (`backend/`, `frontend/`, `images/`).

## What it changes

- Adds `backend/src/main/java/dev/irv/EnvironmentMaintenanceWorker.java`, entirely commented out. It records the daily base-image vulnerability/component updater and Fly API integration updater as deferred work.
- Deletes `.github/workflows/dependency-merge.yml` and `.github/workflows/deploy.yml`.
- Deletes `.github/dependabot.yml` and `renovate.json`, which configured the unwanted repository dependency-update automation.
- Corrects README and operator docs so they no longer claim automatic maintenance, image promotion, or backend deployment is implemented.

`maintenance.yml` and `ci.yml` were already deleted on the checked main branch. This patch does not recreate them or add another workflow.

The existing application, authentication, terminal, logs, cost optimizer, snapshots, runtime cleanup, image recipes, and manual build/deployment tools remain intact. `Maintenance.java` stays executable because it performs runtime cleanup, metrics, and log collection; it is not the deferred updater. No application rebuild or deployment is required for this comment/docs/workflow cleanup.

## Apply with Git

1. Extract this ZIP outside your repository. Keep the extracted `irv-workflow-cleanup` folder together. Merely extracting or uploading the ZIP to GitHub does not apply it.
2. In your irv checkout, make sure `git status --short` is empty. Finish or save your existing work before continuing. Start a new branch from current main; do not reuse a previously merged feature branch:

   ```sh
   git switch main
   git pull --ff-only origin main
   git switch -c chore/defer-environment-maintenance
   ```

   If that new branch name already exists, choose a different unused name.

3. Replace the example patch path below with the actual extracted location. Run the check first; continue only if it succeeds:

   ```sh
   git apply --check --index "/absolute/path/irv-workflow-cleanup/irv-workflow-cleanup.patch"
   git apply --index "/absolute/path/irv-workflow-cleanup/irv-workflow-cleanup.patch"
   git diff --cached --check
   git diff --cached --stat
   git diff --cached
   ```

   `--index` stages the additions, edits, and deletions together. The expected result is **1 added file, 9 edited documentation files, and 4 deleted automation files** (14 paths total).

4. Commit and push your new branch, then open a pull request with **base = main** and **compare = your new branch**:

   ```sh
   git commit -m "Defer environment maintenance and remove workflow substitutes"
   git push -u origin HEAD
   ```

   Review and merge that PR into main to apply the cleanup to the default branch. Do not commit the ZIP, patch-package folder, or `files/` wrapper into the application repository.

If the patch check fails, it has not applied the change. Do not force it or reset your repository. The affected files may have changed, been removed already, or contain local edits. Use the manual method below to reconcile the current files.

## Manual application or instructions for a coding agent

Work on a fresh branch from current main. Treat `files/` inside this ZIP as a repository-root overlay: for example, `files/backend/...` belongs at `backend/...`, not at `files/backend/...` or under an old `irv-unpacked/` directory.

1. Add the comment-only Java file from the matching path in `files/`.
2. Apply the documentation changes shown in `irv-workflow-cleanup.patch`. Full replacement copies are in `files/`; merge the relevant edits if those docs have newer unrelated changes.
3. Explicitly delete every existing path in `DELETE_FILES.txt`. Copying an overlay cannot delete old files. Already missing paths need no action.
4. Keep the previously removed `.github/workflows/maintenance.yml` and `.github/workflows/ci.yml` absent. Do not restore them from the original irv ZIPs. Do not delete a separately created, unrelated workflow without reviewing it.
5. Keep `EnvironmentMaintenanceWorker.java` entirely inside its block comment. Do not add an executable class, Spring component, scheduler, new updater, GitHub workflow, or bot configuration.
6. Keep the running app's `Maintenance.java`, `Optimizer.java`, logs, snapshots, and other runtime behavior unchanged. Keep manual scripts and image recipes. Do not deploy anything as part of applying this patch.
7. Review the changes, commit them, and open the PR targeting main.

## Finish removing existing automation

After the cleanup reaches main:

- In GitHub Actions, cancel any queued or currently running copies of the removed maintenance, dependency-merge, or deployment jobs. Deleting files does not cancel a job already started.
- If existing Dependabot/Renovate update PRs have auto-merge enabled, disable it and close those unwanted update PRs. The patch cannot change PR settings.
- If you separately enabled the Renovate GitHub App for this repo, disable it for this repository as well so it does not reopen onboarding/update PRs after its configuration is removed.
- If a merge is blocked by a required check from the already-deleted `ci.yml`, remove only that obsolete check requirement from the relevant repository rule. Do not recreate the unwanted workflow just to satisfy it.

Old Actions run history can remain visible. Copilot jobs and separately enabled GitHub security services are not the removed repository updater and are not controlled by this patch. This ZIP changes no GitHub account settings, secrets, running Fly resources, database data, or Tigris data.

## Validation and undo

The package was checked by applying the Git patch to clean copies of the affected files retrieved from the stated main revision, checking the resulting changes, and checking that the patch can be reversed. The Java source contains comments only. No runtime implementation was changed, so the application test suites and cloud deployments were not rerun for this cleanup.

To undo after committing, use `git revert` on the cleanup commit (or the PR's squash/merge commit as appropriate), reviewing the restored automation before merging the revert. Do not use a hard reset on a shared branch.

`SHA256SUMS.txt` records the packaged file checksums.
