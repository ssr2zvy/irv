# IRV authentication UI and login fix

Base: ssr2zvy/irv main 19218d03745958f8ecceb76c3424e930f11b4282 (PR #38).
Apply this patch after the previously delivered mandatory-authentication patch.

## Apply and deploy

Extract outside the repository. From your repository root:

```sh
git apply --check /path/to/irv-auth-ui-login-fix-patch/changes.patch
git apply /path/to/irv-auth-ui-login-fix-patch/changes.patch
```

Or run `bash /path/to/irv-auth-ui-login-fix-patch/apply.sh` from the repository root.
Review/commit and redeploy using the existing Docker source workflow. Do not use
the old checked-in JAR. The ZIP contains source changes, not credentials or a deploy.

## Login/download prompt

A real HTTP reproduction of the previous implementation returned an empty 302
redirect to ZITADEL, without an attachment header. The page CSP restricted form
actions to this domain, creating a cross-domain form-redirect problem. The exact
Safari download prompt was not reproduced locally.

The patch replaces the hidden form with POST /auth/login, preserving certificate
admission, Origin and CSRF. It creates the same bound OIDC transaction and returns
JSON. The browser validates the fixed ZITADEL authorization origin/path and
navigates directly. Fetch refuses redirects. There is no downloadable response,
external form submission, or relaxation of the existing security policy. The old
OAuth bootstrap route is locked; callback/PKCE/state/nonce/role checks remain.

## Signup availability

The prior message came from enrollment defaulting to off. This patch enables the
signup menu automatically when these existing Fly runtime secrets are configured:

- IRV_ZITADEL_ENROLLMENT_TOKEN: the dedicated organization-scoped enrollment PAT.
- IRV_AUTH_INVITES_JSON: invite SHA-256 to UTC-expiry map with an unexpired entry.

IRV_AUTH_ENROLLMENT_ENABLED is now an optional override. If you previously set it
to false, remove that override or set true to permit signup. True without a valid
provider token still rejects startup. Do not invent token values; provider setup
is described in docs/flow2-enrollment.md. This patch cannot inspect or populate your
live Fly secrets. It does not disable invitation checks or reuse consumed invites.

The root page fetches /auth/status, which records signup_availability and a fixed
reason: valid, enrollment_disabled, provider_token_missing, invites_not_configured,
or invites_expired. Read that event in application logs to identify the remaining
setting. No configuration warning is printed on the sign-in screen.

## UI

- Compact Sign in page with Use a passkey and a conditional Create account row.
- Account creation has its own form view and icon back navigation.
- Removed the IRV banner, welcome text, explanatory tagline and inline signup warning.
- Preserved the bottom-right diagnostics lock. Diagnostics use an icon back action,
  spaced controls, all eight live checks, and expandable verification limitations.
- Temporary accessible notices for user actions/errors; configuration reasons go to logs.
- Menu/header/icon/spacing patterns follow Telugu-now Settings on GitHub. Uses only
  system fonts and local SVGs, with light/dark appearance and reduced-motion support.
- Other application/sandbox endpoints remain locked.

## Verification

58 JUnit tests passed, zero failures/errors/skips. 9 shipped-client behavior checks
passed, including correct JSON/CSRF handoff, refusal of untrusted URLs or non-JSON
responses, signup navigation and unavailable-status behavior.

The executable JAR built successfully. Real HTTP checks passed under unconfigured
default, configured default, production, legacy profile name and mixed profiles.
Checks include the JSON handoff and absence of Location/Content-Disposition,
secure cookies, certificate and ingress rejection, Origin/CSRF, default route
isolation, and exclusion of authorization URLs and credentials from audit logs.

JavaScript syntax and patch application checks passed. Browser rendering and the
reported Safari prompt were not visually verified: browser downloads were blocked
in this environment. Live Safari/ZITADEL verification is still required after deploy.

Commands from the repository root:

```sh
mvn -f backend/pom.xml test package
node scripts/test-auth-ui.cjs
python3 scripts/test-auth-boundary.py --jar backend/target/irv-0.1.0.jar
```
