#!/usr/bin/env bash
set -euo pipefail
patch_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(git rev-parse --show-toplevel)"
cd "$repo_root"
git apply --check "$patch_dir/changes.patch"
git apply "$patch_dir/changes.patch"
printf '%s\n' 'Patch applied. Review, commit, rebuild and deploy using your existing workflow.'
