# IRV mandatory authentication patch

Base: ssr2zvy/irv main commit 4d23855094a803a7fc38f32a3ddae4facd18b469 (PR #37).

## Apply

Extract this ZIP outside your repository. From the repository root:

```sh
git apply --check /path/to/irv-mandatory-auth-patch/changes.patch
git apply /path/to/irv-mandatory-auth-patch/changes.patch
```

Or run `bash /path/to/irv-mandatory-auth-patch/apply.sh` from the repository root.
The patch includes renames and deletions; do not copy only selected source files.
If the check reports conflicts, reconcile against your current source rather than
forcing application. Commit/rebuild/deploy using your existing workflow.

## Result

- Authentication loads in every profile, including no profile.
- `/` is the signup/passkey sign-in page after certificate/ingress admission.
- One permanent bottom-right lock opens `/auth/diagnostics` with the existing checks.
- Successful login shows a signed-in confirmation; sandbox features stay disabled.
- All unfinished/other routes remain inaccessible even after login.
- Existing secrets, certificate rules, invite policy and enrollment configuration
  are retained. Signup remains conditional on the existing enrollment setting.
- `fly.toml` no longer selects auth-only. An existing secret specifying that name
  remains compatible and does not weaken authentication.

See the patched `docs/mandatory-authentication.md` for routes and deployment details.
The historical internal Java package name is retained; there is no auth-only runtime.

## Validation

50 JUnit tests passed, zero failures/errors/skips. This includes OIDC validation,
invites, ingress secret validation, default authorization, legacy route denial,
and mandatory authentication/isolation under five profile configurations.

Executable JAR built successfully. Real HTTP checks against the JAR passed for
unconfigured default, configured default, production, legacy auth-only name,
and mixed dev/production profiles. Checks cover admission for both pages/assets,
invalid/revoked certificates, missing/wrong secrets, disabled routes, status
redaction, cookie attributes and JSON audit pairing/secret exclusion.

JavaScript syntax check passed. Browser rendering/interaction was not verified:
the available browser download returned invalid archives. Live Cloudflare and
Safari/ZITADEL enrollment/passkey sign-in remain deployment verification steps.

Commands:
```sh
cd backend
mvn test package
cd ..
python3 scripts/test-auth-boundary.py --jar backend/target/irv-0.1.0.jar
node --check backend/src/main/resources/authentication/app.js
```

This is a source patch, not a deployment or a prebuilt JAR. No credentials included.
